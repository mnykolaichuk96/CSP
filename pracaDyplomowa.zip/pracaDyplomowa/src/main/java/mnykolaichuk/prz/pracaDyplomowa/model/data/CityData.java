package mnykolaichuk.prz.pracaDyplomowa.model.data;

public class CityData {

	private Integer cityId;

	private String cityName;

	private Integer workshopCount;

	public CityData() {
	}

	public Integer getCityId() {
		return cityId;
	}

	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public Integer getWorkshopCount() {
		return workshopCount;
	}

	public void setWorkshopCount(Integer workshopCount) {
		this.workshopCount = workshopCount;
	}
}
