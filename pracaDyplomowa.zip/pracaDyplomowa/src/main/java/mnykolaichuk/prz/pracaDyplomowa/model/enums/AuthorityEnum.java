package mnykolaichuk.prz.pracaDyplomowa.model.enums;

public enum AuthorityEnum {
    ROLE_CUSTOMER,
    ROLE_WORKSHOP,
    ROLE_ADMIN
}
