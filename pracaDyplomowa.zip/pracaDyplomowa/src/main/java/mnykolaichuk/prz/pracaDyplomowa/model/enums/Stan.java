package mnykolaichuk.prz.pracaDyplomowa.model.enums;

public enum Stan {
    CREATED,
    WORKSHOP_ANSWER,
    IMPLEMENTATION,
    COMPLETED,
    UNREGISTERED
}
